package com.boot.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.stereotype.Service;

import com.boot.user.Entity.User;
import com.boot.user.repo.UserRepository;


@Service
public class DBinit implements CommandLineRunner {
	@Autowired
	UserRepository repository;

	Logger logger = LoggerFactory.getLogger(DBinit.class);

	@Override
	public void run(String... args) throws Exception {

		repository.save(new User(10, "Suresh kumar",9876543210L));
		repository.save(new User(20, "Hari Madhwa",9834657255L));
		repository.save(new User(30, "Kiran Singh",8876544516L));
		repository.save(new User(40, "Sham Kulkarni",7676543245L));
		repository.save(new User(50, "Paresh Jain",8176532291L));
		
		logger.info("Initial User objects added to the table");

	}

}