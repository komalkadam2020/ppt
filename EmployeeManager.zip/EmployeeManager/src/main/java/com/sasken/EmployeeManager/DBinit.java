package com.sasken.EmployeeManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.stereotype.Service;

import com.sasken.EmployeeManager.Entity.Employee;
import com.sasken.EmployeeManager.repo.EmployeeRepo;

@Service
public class DBinit implements CommandLineRunner {
	@Autowired
	EmployeeRepo repository;

	Logger logger = LoggerFactory.getLogger(DBinit.class);

	@Override
	public void run(String... args) throws Exception {

		repository.save(new Employee(1L, "Suresh kumar", "suresh@gmail.com","Software Engineer","9876543210","https://bootdey.com/img/Content/avatar/avatar6.png","ee100"));
		repository.save(new Employee(2L, "Reyna Reddy" ,"reyna@gmail.com","Senior Engineer","9876543210","https://bootdey.com/img/Content/avatar/avatar3.png","ee200"));
		repository.save(new Employee(3L, "Anil Jain", "anil@gmail.com","Lead Engineer","9876543210","https://bootdey.com/img/Content/avatar/avatar6.png","ee300"));
		repository.save(new Employee(4L, "Sidharth Reddy", "sidharth@gmail.com","Software Engineer","9876543210","https://bootdey.com/img/Content/avatar/avatar6.png","ee400"));
		repository.save(new Employee(5L, "Akhila Kaur", "akhila@gmail.com","Senior Engineer","9876543210","https://bootdey.com/img/Content/avatar/avatar3.png","ee500"));
		

		logger.info("Initial Employee objects added to the table");

	}

}