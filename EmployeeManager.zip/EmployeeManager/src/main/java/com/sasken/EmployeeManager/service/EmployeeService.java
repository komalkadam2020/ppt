package com.sasken.EmployeeManager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sasken.EmployeeManager.Entity.Employee;
import com.sasken.EmployeeManager.exception.EmployeeDuplicateException;
import com.sasken.EmployeeManager.exception.EmployeeNotFoundException;
import com.sasken.EmployeeManager.repo.EmployeeRepo;


@Service
public class EmployeeService {
	
	private EmployeeRepo employeeRepo;
	
	@Autowired
	public EmployeeService(EmployeeRepo employeeRepo) {
		this.employeeRepo=employeeRepo;
	}
	
	public void addEmployee(Employee employee) {
		if (employeeRepo.existsById(employee.getId()))
			throw new EmployeeDuplicateException("SAVE_FAIL", "Employee with id " + employee.getId() + " already exists");
		employeeRepo.save(employee);
	}
	
	public List<Employee> findAllEmployees() {

		List<Employee> list = employeeRepo.findAll();
		return list;
	}
	
	public Employee findEmployeeById(Long id) {
		Optional<Employee> opt = employeeRepo.findById(id);
		if (!opt.isPresent())
			throw new EmployeeNotFoundException("NOT_FOUND", "Employee data with id " + id + " not found");
		return opt.get();
	}

	public void updateEmployee(Employee e) {
		if (employeeRepo.existsById(e.getId()))
			employeeRepo.save(e);
		else
			throw new EmployeeNotFoundException("UPDATE_FAIL",
					"Employee with id " + e.getId() + " to update not found");

	}

	
	public void deleteEmployee(long id) {
		if (employeeRepo.existsById(id)) {
			employeeRepo.deleteById(id);
			
		} else {
			throw new EmployeeNotFoundException("NOT_FOUND", "Employee data with id " + id + " to delete not found");
		}

	}
	
	
	   
	
	
}
